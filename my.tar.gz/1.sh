#!/bin/bash
if [ -f /tmp/int/1.txt ];
then 
echo "yo"
else
echo "no"
fi
